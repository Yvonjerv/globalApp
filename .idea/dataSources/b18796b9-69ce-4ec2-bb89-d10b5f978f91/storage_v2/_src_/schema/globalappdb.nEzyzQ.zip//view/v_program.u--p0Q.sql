create definer = root@localhost view v_program as
select `globalappdb`.`t_location`.`city`             AS `city`,
       `globalappdb`.`t_location`.`province`         AS `province`,
       `globalappdb`.`t_location`.`type`             AS `type`,
       `globalappdb`.`t_location`.`population`       AS `population`,
       `globalappdb`.`t_major`.`majorid`             AS `majorid`,
       `globalappdb`.`t_major`.`majorname`           AS `majorname`,
       `globalappdb`.`t_major`.`researcharea`        AS `researcharea`,
       `globalappdb`.`t_major`.`majordesc`           AS `majordesc`,
       `globalappdb`.`t_major`.`departmentid`        AS `departmentid`,
       `globalappdb`.`t_program`.`programid`         AS `programid`,
       `globalappdb`.`t_program`.`degreeid`          AS `degreeid`,
       `globalappdb`.`t_program`.`duration`          AS `duration`,
       `globalappdb`.`t_program`.`langId`            AS `langId`,
       `globalappdb`.`t_program`.`status`            AS `status`,
       `globalappdb`.`t_program`.`startdate`         AS `startdate`,
       `globalappdb`.`t_program`.`enddate`           AS `enddate`,
       `globalappdb`.`t_program`.`notes`             AS `notes`,
       `globalappdb`.`t_university`.`universityname` AS `universityname`,
       `globalappdb`.`t_university`.`locationid`     AS `locationid`,
       `globalappdb`.`t_university`.`universitydesc` AS `universitydesc`,
       `globalappdb`.`t_university`.`weburl`         AS `weburl`,
       `globalappdb`.`t_university`.`universityKey`  AS `universityKey`,
       `globalappdb`.`t_degree`.`degreename`         AS `degreename`,
       `globalappdb`.`t_degree`.`degreedesc`         AS `degreedesc`,
       `globalappdb`.`t_degree`.`requirement_id`     AS `requirement_id`,
       `globalappdb`.`t_department`.`departmentname` AS `departmentname`,
       `globalappdb`.`t_department`.`departmentdesc` AS `departmentdesc`,
       `globalappdb`.`t_department`.`universityid`   AS `universityid`,
       `globalappdb`.`t_language`.`language`         AS `language`,
       `globalappdb`.`t_language`.`description`      AS `description`
from ((((((`globalappdb`.`t_location` join `globalappdb`.`t_university` on ((`globalappdb`.`t_location`.`locationid` =
                                                                             `globalappdb`.`t_university`.`locationid`))) join `globalappdb`.`t_department` on ((
        `globalappdb`.`t_department`.`universityid` =
        `globalappdb`.`t_university`.`universityid`))) join `globalappdb`.`t_major` on ((
        `globalappdb`.`t_department`.`departmentid` =
        `globalappdb`.`t_major`.`departmentid`))) join `globalappdb`.`t_program` on ((
        `globalappdb`.`t_major`.`majorid` = `globalappdb`.`t_program`.`majorid`))) join `globalappdb`.`t_degree` on ((
        `globalappdb`.`t_degree`.`degreeid` = `globalappdb`.`t_program`.`degreeid`)))
         join `globalappdb`.`t_language`
              on ((`globalappdb`.`t_language`.`langId` = `globalappdb`.`t_program`.`langId`)));

